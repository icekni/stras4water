<?php

namespace App\Controller;

use App\Entity\Abonnement;
use App\Entity\Carte;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;

final class CartController extends AbstractController
{
    #[Route('/panier/ajouter', name: 'cart_add', methods: ['POST'])]
    public function addToCart(Request $request, SessionInterface $session, EntityManagerInterface $em): Response
    {
        if (!$this->getUser()) {
            $this->addFlash('warning', 'Vous devez être connecté pour ajouter un abonnement ou une carte au panier.');
            return $this->redirectToRoute('app_login');
        }

        /** @var User $user */
        $user = $this->getUser();

        $type = $request->request->get('type');
        $id = (int)$request->request->get('id');

        if (!in_array($type, ['abonnement', 'carte'], true)) {
            $this->addFlash('danger', 'Type invalide.');
            return $this->redirectToRoute('home');
        }

        if ($type === 'abonnement') {
            $entity = $em->getRepository(Abonnement::class)->find($id);
        } else {
            $entity = $em->getRepository(Carte::class)->find($id);
        }

        if (!$entity) {
            $this->addFlash('danger', 'Article non trouvé.');
            return $this->redirectToRoute('home');
        }

        $cart = $session->get('cart', ['items' => [], 'adhesion_added' => false]);

        if (!$user->isAdherent() && !$cart['adhesion_added']) {
            $cart['items'][] = [
                'type' => 'adhesion',
                'id' => null,
            ];
            $cart['adhesion_added'] = true;
            $this->addFlash('info', 'Une adhésion obligatoire a été ajoutée à votre panier.');
        }

        foreach ($cart['items'] as $item) {
            if ($item['type'] === $type && $item['id'] === $id) {
                $this->addFlash('warning', 'Cet article est déjà dans votre panier.');
                return $this->redirectToRoute('cart_show');
            }
        }

        $cart['items'][] = [
            'type' => $type,
            'id' => $id,
        ];

        $session->set('cart', $cart);

        $this->addFlash('success', "Article ajouté au panier.");

        return $this->redirectToRoute('cart_show');
    }

    #[Route('/panier', name: 'cart_show', methods: ['GET'])]
    public function showCart(SessionInterface $session, EntityManagerInterface $em): Response
    {
        $cart = $session->get('cart', ['items' => [], 'adhesion_added' => false]);
        dd($cart);

        $itemsDetails = [];
        foreach ($cart['items'] as $item) {
            if ($item['type'] === 'abonnement') {
                $entity = $em->getRepository(Abonnement::class)->find($item['id']);
            } elseif ($item['type'] === 'carte') {
                $entity = $em->getRepository(Carte::class)->find($item['id']);
            } elseif ($item['type'] === 'adhesion') {
                $entity = null;
            }

            if ($entity) {
                $itemsDetails[] = [
                    'type' => $item['type'],
                    'entity' => $entity,
                    'qty' => $item['qty'],
                ];
            } else if ($item['type'] === 'adhesion') {
                $itemsDetails[] = [
                    'type' => 'adhesion',
                    'label' => 'Adhésion obligatoire',
                    'qty' => 1,
                ];
            }
        }

        return $this->render('cart/show.html.twig', [
            'items' => $itemsDetails,
        ]);
    }
}